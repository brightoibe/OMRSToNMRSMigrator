#!/bin/bash 
java -jar OMRSToNMRSmigrator.jar

