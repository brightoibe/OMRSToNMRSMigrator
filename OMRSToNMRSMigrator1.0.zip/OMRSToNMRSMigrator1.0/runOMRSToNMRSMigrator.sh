#!/bin/bash 
java -jar EHealthDataPump8.2.jar

